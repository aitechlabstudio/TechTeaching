#!/usr/bin/env python3
import argparse
import base64
import json
import mimetypes
import os
import pathlib
import sys
import urllib.error
import urllib.request


DEFAULT_BASE_URL = "https://apihub.agnes-ai.com"
MODEL_BY_VERSION = {
    "2.0": "agnes-image-2.0-flash",
    "2.1": "agnes-image-2.1-flash",
}


def resolve_api_key(env_name):
    return os.environ.get(env_name, "")


def parse_api_key_file(path, env_name):
    key_path = pathlib.Path(path)
    if not key_path.exists():
        return ""

    for raw_line in key_path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" not in line:
            return line.strip().strip("\"'")

        name, value = line.split("=", 1)
        if name.strip() == env_name:
            return value.strip().strip("\"'")

    return ""


def resolve_api_key_from_args(env_name, api_key_file):
    api_key = resolve_api_key(env_name)
    if api_key:
        return api_key

    if api_key_file:
        return parse_api_key_file(api_key_file, env_name)

    return parse_api_key_file(".env", env_name)


def image_file_to_data_uri(path):
    image_path = pathlib.Path(path)
    if not image_path.exists():
        raise SystemExit(f"Input image file does not exist: {image_path}")
    if not image_path.is_file():
        raise SystemExit(f"Input image path is not a file: {image_path}")

    mime_type, _ = mimetypes.guess_type(str(image_path))
    if not mime_type or not mime_type.startswith("image/"):
        mime_type = "image/png"

    encoded = base64.b64encode(image_path.read_bytes()).decode("ascii")
    return f"data:{mime_type};base64,{encoded}"


def normalize_image_input(value):
    if value.startswith(("http://", "https://", "data:image/")):
        return value
    return image_file_to_data_uri(value)


def choose_model(version, model):
    if model:
        return model
    return MODEL_BY_VERSION[version]


def build_payload(args):
    images = [normalize_image_input(image) for image in args.image]
    payload = {
        "model": choose_model(args.version, args.model),
        "prompt": args.prompt,
        "size": args.size,
    }

    if args.return_base64:
        payload["return_base64"] = True

    extra_body = {}
    if args.response_format:
        extra_body["response_format"] = args.response_format

    if images:
        if args.image_placement == "top_level":
            payload["image"] = images
        else:
            extra_body["image"] = images

    if extra_body:
        payload["extra_body"] = extra_body

    return payload


def request_json(url, api_key, payload, timeout):
    data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        body = exc.read().decode("utf-8", errors="replace")
        raise SystemExit(f"Agnes API HTTP {exc.code}: {body}") from exc
    except urllib.error.URLError as exc:
        raise SystemExit(f"Agnes API request failed: {exc}") from exc


def write_json(path, value):
    output_path = pathlib.Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")


def extract_first_result(response):
    data = response.get("data") or []
    if not data:
        raise SystemExit(f"Agnes response has no data: {json.dumps(response, ensure_ascii=False)}")

    first = data[0]
    if not isinstance(first, dict):
        raise SystemExit(f"Agnes response data[0] is not an object: {json.dumps(response, ensure_ascii=False)}")
    return first


def download_url(url, output_path, timeout):
    with urllib.request.urlopen(url, timeout=timeout) as response:
        output_path.write_bytes(response.read())


def save_result(response, output_path, download_timeout):
    first = extract_first_result(response)
    b64_json = first.get("b64_json")
    image_url = first.get("url")

    output_path = pathlib.Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    if b64_json:
        output_path.write_bytes(base64.b64decode(b64_json))
        return output_path

    if image_url:
        download_url(image_url, output_path, download_timeout)
        return output_path

    raise SystemExit(f"Agnes response has neither url nor b64_json: {json.dumps(response, ensure_ascii=False)}")


def write_url_if_requested(response, url_output):
    if not url_output:
        return

    first = extract_first_result(response)
    image_url = first.get("url")
    if not image_url:
        raise SystemExit("Cannot write URL file because the Agnes response did not include data[0].url")

    output_path = pathlib.Path(url_output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(image_url + "\n", encoding="utf-8")


def parse_args(argv):
    parser = argparse.ArgumentParser(
        description="Generate, edit, or compose images with Agnes Image 2.0 Flash and 2.1 Flash."
    )
    parser.add_argument("--prompt", required=True, help="Text prompt or image editing instruction.")
    parser.add_argument("--output", default="outputs/agnes-image.png", help="Image file to save.")
    parser.add_argument("--size", default="1024x768", help="Output size, for example 1024x768, 1024x1024, or 768x1024.")
    parser.add_argument(
        "--version",
        choices=sorted(MODEL_BY_VERSION),
        default="2.1",
        help="Agnes Image Flash version to use when --model is not provided.",
    )
    parser.add_argument("--model", help="Override the model name directly.")
    parser.add_argument(
        "--image",
        action="append",
        default=[],
        help="Input image URL, Data URI, or local file path. Repeat for image-to-image or multi-image composition.",
    )
    parser.add_argument(
        "--image-placement",
        choices=["extra_body", "top_level"],
        default="extra_body",
        help="Where to send input images. The guide examples use extra_body; top_level is available for compatibility.",
    )
    parser.add_argument(
        "--response-format",
        choices=["url", "b64_json"],
        default="url",
        help="Value for extra_body.response_format. Use b64_json for Base64 output.",
    )
    parser.add_argument(
        "--return-base64",
        action="store_true",
        help="Send top-level return_base64=true. This is mainly for text-to-image Base64 output.",
    )
    parser.add_argument("--raw-output", help="Optional path to save the raw JSON API response.")
    parser.add_argument("--url-output", help="Optional path to save data[0].url as text when URL output is returned.")
    parser.add_argument("--dry-run", action="store_true", help="Print the request payload and exit without calling the API.")
    parser.add_argument("--base-url", default=os.environ.get("AGNES_BASE_URL", DEFAULT_BASE_URL), help="Agnes base URL.")
    parser.add_argument("--api-key-env", default="AGNES_API_KEY", help="Environment variable containing the Agnes API key.")
    parser.add_argument(
        "--api-key-file",
        default=os.environ.get("AGNES_API_KEY_FILE"),
        help="Optional file containing the API key, either as AGNES_API_KEY=... or as the raw key. Defaults to .env if present.",
    )
    parser.add_argument("--timeout", type=int, default=360, help="API request timeout in seconds.")
    parser.add_argument("--download-timeout", type=int, default=120, help="Generated image download timeout in seconds.")
    return parser.parse_args(argv)


def main(argv=None):
    args = parse_args(argv or sys.argv[1:])
    payload = build_payload(args)

    if args.dry_run:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return

    api_key = resolve_api_key_from_args(args.api_key_env, args.api_key_file)
    if not api_key:
        raise SystemExit(f"Missing {args.api_key_env}. Set it in the environment, in .env, or pass --api-key-file.")

    endpoint = args.base_url.rstrip("/") + "/v1/images/generations"
    response = request_json(endpoint, api_key, payload, args.timeout)

    if args.raw_output:
        write_json(args.raw_output, response)
    write_url_if_requested(response, args.url_output)

    output_path = save_result(response, args.output, args.download_timeout)
    print(output_path)


if __name__ == "__main__":
    main()
