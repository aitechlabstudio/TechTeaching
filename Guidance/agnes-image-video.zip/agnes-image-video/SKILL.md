---
name: agnes-image-generator
description: Use when the user wants to generate, edit, transform, or compose images or videos with Agnes AI models from Claude Code, including Agnes Image 2.0 Flash, Agnes Image 2.1 Flash, Agnes Video V2.0, text-to-image, image-to-image, text-to-video, image-to-video, multi-image composition, or saving generated media locally.
---

# Agnes Image Generator

Use Agnes directly from Claude Code for image and video generation. Do not switch Claude Code's main chat model to an image or video model.

## Requirements

- API key provided by the user in `AGNES_API_KEY`.
- Python 3
- Image endpoint: `https://apihub.agnes-ai.com/v1/images/generations`
- Video create endpoint: `https://apihub.agnes-ai.com/v1/videos`
- Video status endpoint: `https://apihub.agnes-ai.com/agnesapi?video_id=...`
- Default image model: `agnes-image-2.1-flash`
- Supported image models: `agnes-image-2.0-flash`, `agnes-image-2.1-flash`
- Default video model: `agnes-video-v2.0`

If `AGNES_API_KEY` is missing, ask the user to export it. Never store the key in the skill or scripts.

## Quick Use

First configure the API key in `.env`:

```bash
AGNES_API_KEY=your Agnes API key
```

Or configure it in the shell:

```bash
export AGNES_API_KEY="your Agnes API key"
```

Run the bundled script:

```bash
python ~/.claude/skills/agnes-image-generator/scripts/agnes_image.py \
  --version 2.1 \
  --prompt "A clean product photo of a glass cube on a white studio background, soft shadows, high detail" \
  --output outputs/agnes-image.png
```

For editing, image-to-image, or multi-image composition, pass one or more public image URLs, Data URI strings, or local image file paths:

```bash
python ~/.claude/skills/agnes-image-generator/scripts/agnes_image.py \
  --version 2.1 \
  --prompt "Transform this image into a cinematic cyberpunk style while preserving the main subject" \
  --image "https://example.com/input.png" \
  --output outputs/agnes-edit.png
```

Use `--version 2.0` to call `agnes-image-2.0-flash`, or `--model` to pass a model name directly.

For text-to-video:

```bash
python ~/.claude/skills/agnes-image-generator/scripts/agnes_video.py \
  --prompt "A cinematic shot of a cat walking on the beach at sunset, soft ocean waves, warm golden lighting, realistic motion" \
  --num-frames 121 \
  --frame-rate 24 \
  --output outputs/agnes-video.mp4
```

For image-to-video:

```bash
python ~/.claude/skills/agnes-image-generator/scripts/agnes_video.py \
  --prompt "Animate the character with subtle breathing motion and cinematic camera movement" \
  --image "https://example.com/input.png" \
  --output outputs/agnes-image-video.mp4
```

For multi-image video or keyframe animation:

```bash
python ~/.claude/skills/agnes-image-generator/scripts/agnes_video.py \
  --prompt "Create a smooth cinematic transition between the two keyframes while maintaining visual consistency" \
  --image "https://example.com/keyframe-1.png" \
  --image "https://example.com/keyframe-2.png" \
  --keyframes \
  --output outputs/agnes-keyframes.mp4
```

## API Notes

- Use `POST https://apihub.agnes-ai.com/v1/images/generations`.
- Put `response_format` under `extra_body`, not at the top level.
- For text-to-image, do not include `image`.
- For image editing or multi-image composition, the script puts images in `extra_body.image` by default. Use `--image-placement top_level` only for compatibility testing.
- Use a long timeout; image generation can take several seconds to minutes.
- Video generation is asynchronous: create a task, poll by `video_id`, then download the completed mp4.
- New video retrieval should use `video_id`; legacy retrieval can use `task_id`.
- For single image-to-video, the script sends top-level `image`. For multiple images or keyframes, it sends `extra_body.image`.
- For video, `num_frames` must be `<= 441` and follow `8n + 1`, for example `81`, `121`, `161`, `241`, or `441`.

## Useful Options

```bash
python ~/.claude/skills/agnes-image-generator/scripts/agnes_image.py --help
python ~/.claude/skills/agnes-image-generator/scripts/agnes_video.py --help
```

Common flags:

- `--prompt`: required text prompt.
- `--output`: destination image path.
- `--version`: `2.0` or `2.1`, defaults to `2.1`.
- `--model`: override the model name directly.
- `--size`: defaults to `1024x768`.
- `--image`: public URL, Data URI, or local file path. Repeat for image-to-image or multi-image composition.
- `--response-format`: `url` or `b64_json`, defaults to `url`.
- `--return-base64`: request top-level `return_base64=true`, mainly for text-to-image Base64 output.
- `--dry-run`: print the JSON payload without calling the API.
- `--url-output`: save returned `data[0].url` to a text file when URL output is returned.
- `--raw-output`: save raw JSON response for debugging.
- `--api-key-file`: read the API key from a file. The scripts automatically read `.env` if it exists.

Common video flags:

- `--prompt`: required when creating a new video task.
- `--image`: public image URL. Repeat for multi-image or keyframe workflows.
- `--keyframes`: set `extra_body.mode` to `keyframes`; requires at least two images.
- `--multi-image`: force `extra_body.image` for image inputs.
- `--width`, `--height`: requested video dimensions. Agnes may standardize output size.
- `--num-frames`: defaults to `121`, must follow `8n + 1`.
- `--frame-rate`: defaults to `24`, supports `1` to `60`.
- `--seed`, `--negative-prompt`, `--num-inference-steps`: optional generation controls.
- `--no-wait`: create a task and print JSON without polling.
- `--video-id` or `--task-id`: resume polling or retrieve an existing task.
- `--status-only`: fetch one status response without downloading.
- `--dry-run`: print the create-task JSON payload without calling the API.
- `--raw-output`: save the create/status/final JSON response.
- `--url-output`: save the completed MP4 URL to a text file.
- `--api-key-file`: read the API key from a file. The scripts automatically read `.env` if it exists.

## Prompt Pattern

Text-to-image:

```text
[Main subject] + [Scene/background] + [Style] + [Lighting] + [Composition] + [Quality requirements]
```

Image editing:

```text
[Editing instruction] + [Elements to preserve] + [Target style/scene] + [Lighting] + [Quality requirements]
```
